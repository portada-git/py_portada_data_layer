# PY_PORTADA_DATA_LAYER
This library must be used to save and read spark dataframes in a data lake  

<!--stackedit_data:
eyJoaXN0b3J5IjpbMTM4Njg2ODUwXX0=
-->